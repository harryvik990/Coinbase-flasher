# Coinbase Flasher Simulator

⚠️ **Educational Use Only!**
This tool mimics the appearance of a Coinbase transaction sender, but does NOT interact with any real blockchain or send actual funds.

## Features
- Fake BTC send UI
- Generates a mock TXID
- Prank or test apps safely

## Usage
1. Open `index.html` in your browser.
2. Fill out wallet + amount.
3. View simulated result.

## Disclaimer
This is not a real crypto tool. No real coins are involved.
